package com.example.demotransaction.entity;

public enum AccountState {
    ACTIVE,
    DISABLED
}
