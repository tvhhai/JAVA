package com.example.demotransaction.exception;

public class DummyException extends RuntimeException{
}
